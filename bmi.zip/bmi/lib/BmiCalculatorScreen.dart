import 'package:bmi/ResultScreen.dart';
import 'package:flutter/material.dart';

import 'bmimodels.dart';

class BmiCalculatorScreen extends StatefulWidget {
  // const BmiCalculatorScreen({super.key});

  @override
  State<BmiCalculatorScreen> createState() => _BmiCalculatorScreenState();
}

class _BmiCalculatorScreenState extends State<BmiCalculatorScreen> {
  @override
  double _heightOftheUser = 100.0;
  double _weightOftheUser = 40.0;
  double _bmi = 0;
  // BmiCalculatorScreen
  late BMImodel _bmImodelObject;

  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.only(top: 150, left: 32, right: 32),
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              "lib/images/heart.png",
              height: 300,
              width: 300,
            ),
            Text(
              "BMI Calculator",
              style: TextStyle(fontSize: 50, color: Colors.red[700]),
            ),
            Text(
              "WE care about your health",
              style: TextStyle(fontSize: 20, color: Colors.grey),
            ),
            SizedBox(
              height: 30,
            ),
            Text(
              "Height(CM)",
              style: TextStyle(fontSize: 40, color: Colors.grey),
            ),
            SizedBox(
              height: 40,
            ),
            Container(
              padding: EdgeInsets.only(left: 16, right: 16),
              child: Slider(
                min: 80,
                max: 250,
                onChanged: (height) {
                  setState(() {
                    _heightOftheUser = height;
                  });
                },
                value: _heightOftheUser,
                divisions: 100,
                activeColor: Colors.red,
                label: "$_heightOftheUser",
              ),
            ),
            Text(
              "$_heightOftheUser CM",
              style: TextStyle(fontSize: 25, color: Colors.red),
            ),
            SizedBox(
              height: 30,
            ),
            Text(
              "Weight(KG)",
              style: TextStyle(fontSize: 40, color: Colors.grey),
            ),
            Container(
              padding: EdgeInsets.only(left: 16, right: 16),
              child: Slider(
                min: 30,
                max: 120,
                onChanged: (weight) {
                  setState(() {
                    _weightOftheUser = weight;
                  });
                },
                value: _weightOftheUser,
                divisions: 100,
                activeColor: Colors.red,
                label: "$_weightOftheUser",
              ),
            ),
            Text(
              "$_weightOftheUser KG",
              style: TextStyle(fontSize: 25, color: Colors.red),
            ),
            SizedBox(
              height: 20,
            ),
            GestureDetector(
              onTap: () {
                setState(() {
                  _bmi = _weightOftheUser /
                      ((_heightOftheUser) / 100 * (_heightOftheUser / 100));
                  print("the bmi is: " + '{$_bmi}');

                  if (_bmi >= 18.5 && _bmi <= 25) // between: 18.5 - 25
                  {
                    _bmImodelObject = BMImodel(
                        bmi: _bmi,
                        isNormal: true,
                        comments: "You are Totaly Fit.");
                  } else if (_bmi < 18.5) {
                    /// kayar 18.5
                    _bmImodelObject = BMImodel(
                        bmi: _bmi,
                        isNormal: false,
                        comments: "You are Underweighted.");
                  } else if (_bmi > 25 && _bmi <= 30) {
                    //// betweebL 25 - 30
                    _bmImodelObject = BMImodel(
                        bmi: _bmi, isNormal: false, comments: "You are Over.");
                  } else {
                    // kabadan 30.....
                    _bmImodelObject = BMImodel(
                        bmi: _bmi,
                        isNormal: false,
                        comments: "You are Obsesed...");
                  }
                });
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ResultScreen(
                              bmiModel: _bmImodelObject,
                            )));
              },
              child: Container(
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: Colors.red, borderRadius: BorderRadius.circular(12)),
                // width: ,
                child:
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(
                    Icons.favorite,
                    color: Colors.white,
                    size: 30,
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    "Calculate",
                    style: TextStyle(fontSize: 30),
                  )
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
