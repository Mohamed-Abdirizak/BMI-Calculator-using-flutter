import 'package:bmi/bmimodels.dart';
import 'package:flutter/material.dart';

import 'BmiCalculatorScreen.dart';

class ResultScreen extends StatelessWidget {
  final bmiModel;

  const ResultScreen({super.key, required this.bmiModel});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
          child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.only(left: 20, right: 20, top: 100),
              // height: 20,
              // width: 200,
              child: bmiModel.isNormal
                  ? Image.asset(
                      "lib/images/happiness.png",
                      height: 300,
                      width: 300,
                      fit: BoxFit.contain,
                    )
                  : Image.asset(
                      "lib/images/sad.png",
                      fit: BoxFit.contain,
                      height: 300,
                      width: 300,
                    ),
            ),
            SizedBox(
              height: 20,
            ),
            Text(
              "Your BMI is ${bmiModel.bmi}",
              style: TextStyle(
                  color: Colors.red[700],
                  fontSize: 30,
                  fontWeight: FontWeight.w700),
            ),
            Text(
              "${bmiModel.comments}",
              style: TextStyle(
                  color: Colors.grey[700],
                  fontSize: 18,
                  fontWeight: FontWeight.w500),
            ),
            SizedBox(
              height: 20,
            ),
            bmiModel.isNormal
                ? Text(
                    "Fatih!, Your BMI is Normal.",
                    style: TextStyle(
                        color: Colors.red[700],
                        fontSize: 25,
                        fontWeight: FontWeight.w700),
                  )
                : Text(
                    "Sadly! Your BMI is not Normal.",
                    style: TextStyle(
                        color: Colors.red[700],
                        fontSize: 25,
                        fontWeight: FontWeight.w700),
                  ),
            SizedBox(
              height: 30,
            ),
            GestureDetector(
              onTap: () => Navigator.pop(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ResultScreen(
                            bmiModel: BmiCalculatorScreen(),
                          ))),
              child: Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                    color: Colors.red, borderRadius: BorderRadius.circular(12)),
                // width: ,
                child:
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(
                    Icons.arrow_back,
                    color: Colors.white,
                    size: 30,
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    "Go back to the Calculator",
                    style: TextStyle(fontSize: 30),
                  )
                ]),
              ),
            ),
          ],
        ),
      )),
    );
  }
}
