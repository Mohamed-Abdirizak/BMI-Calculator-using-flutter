class BMImodel {
  double bmi;
  bool isNormal;
  String comments;

  BMImodel({required this.bmi, required this.isNormal, required this.comments});
}
